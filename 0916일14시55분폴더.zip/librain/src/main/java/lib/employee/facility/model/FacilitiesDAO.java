package lib.employee.facility.model;

import java.util.List;

public interface FacilitiesDAO {
	public List<FacilitiesDTO> facSelect();

}
